import sys, os, argparse, datetime
import tabulate


#region Read version
version = open("./version.txt").read()
#endregion /Read version


#region Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument('-c', '--dhcpd-config-path', help='Path to the DHCPD config', required=False)
parser.add_argument('-o', '--output-file', help='Output file name', required=False, default=None)
parser.add_argument('-l', '--log-file', help='Log file name', required=False, default=None)
parser.add_argument('-v', '--version', help='Print version', action='store_true')
args = parser.parse_args()
#endregion /Parse arguments


#region Print version
if args.version:
    sys.path.append(".")
    import src.common
    src.common.print_version("DHCP, Entry Point: local")
    sys.exit(0)
#endregion /Print version


#region Import helpers
sys.path.append(".")
import src.common, src.dhcpd, src.ib
print("")
from src import YELLOW, RED, RESET
#endregion /Import helpers


#region Set environment variables
os.environ['ib_datetime'] = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
os.environ['ib_server_directory'] = "/"

src.common.set_global_vars(args)
    

if args.dhcpd_config_path is None or args.dhcpd_config_path == "":
    src.common.write_log("DHCPD config path was not provided as parameter. Trying to locate in automatically.", verbose=True)
    os.environ['ib_dhcpd_config_path'] = src.dhcpd.get_config_path(os.environ['ib_server'])
    if os.environ['ib_dhcpd_config_path'] == "":
        src.common.write_log(f"{RED}Could not find location for DHCPD config file. Exiting.{RESET}", severity="Warning", verbose=True)
        exit(1)
    src.common.write_log(f"Detected at: '{os.environ['ib_dhcpd_config_path']}'.", verbose=True)
else:
    os.environ['ib_dhcpd_config_path'] = args.dhcpd_config_path
    src.common.write_log(f"Using DHCPD config file provided by parameter: '{os.environ['ib_dhcpd_config_path']}'.", verbose=True)
    
    
print("Detecting location of the BIND leases file ... ", end="")
src.common.write_log("Detecting location of the BIND leases file.")
os.environ['ib_dhcpd_leases_path'] = src.dhcpd.get_leases_path(os.environ['ib_server'])
if os.environ['ib_dhcpd_leases_path'] == "":
    src.common.write_log(f"{RED}Could not find location for DHCPD leases file. Exiting.{RESET}", severity="Error", verbose=True)
    exit(1)
print("done.")
src.common.write_log(f"Found at location '{os.environ['ib_dhcpd_leases_path']}'.", verbose=True)
#endregion /Set environment variables


#region Print version
src.common.write_log(f"Script version: {version}", verbose=True)
src.common.write_log("Mode: locally process server data.", new_line=True, verbose=True)
#endregion /Print version


#region Get local server IP address
servers = [src.common.get_local_ip()]
src.common.write_log(f"Server IP address detected: '{servers}'.", verbose=True)
#region Get local server IP address


servers_stats = dict()


#region Loop through servers
for server in servers:
    src.common.write_log(" ", verbose=True)
    src.common.write_log(f"Processing '{server}' server.", verbose=True)
    os.environ['ib_server'] = server
    
    
    #region Parse config
    print("Parsing DHCPD config files... ", end = "")
    src.common.write_log("Parsing DHCPD config files.")
    dhcpd_config = src.dhcpd.parse_config(os.environ['ib_server_directory'], os.environ['ib_dhcpd_config_path'])
    print("done.")
    #endregion /Parse config
    
    
    #region Parse leases
    print("Parsing DHCPD leases file... ", end = "")
    src.common.write_log("Parsing DHCPD lease file.")
    dhcpd_leases = src.dhcpd.parse_leases(os.environ['ib_dhcpd_leases_path'])
    print("done.")
    #endregion /Parse leases
    
    
    #region Calculate metrics
    servers_stats[server] = dict()
    servers_stats[server]['gen_vendor'] = src.common.get_linux_version()
    servers_stats[server]['dhcp_vendor'] = src.dhcpd.get_server_version(os.environ['ib_server'])
    servers_stats[server]['dhcp_server_count'] = src.ib.dhcp_server_count()
    servers_stats[server]['dhcp_subnet_count'] = src.ib.dhcp_subnet_count(dhcpd_config)
    servers_stats[server]['dhcp_device_count'] = src.ib.dhcp_device_count(dhcpd_config, dhcpd_leases)
    servers_stats[server]['dhcp_lease_time'] = src.ib.dhcp_lease_time(dhcpd_config)
    servers_stats[server]['dhcp_lps'] = src.ib.dhcp_lps(dhcpd_leases)
    #endregion /Calculate metrics

#endregion /Loop through servers


#region Print raw metrics for all servers
src.common.write_log(" ", verbose=True)
src.common.write_log(servers_stats, verbose=True, new_line=True)
#endregion /Print raw metrics for all servers


#region Print average metrics for all servers
csv_dict = dict()

print("\n")
metrics = [
    'gen_vendor',
    'dhcp_vendor',
    'dhcp_server_count',
    'dhcp_subnet_count',
    'dhcp_device_count',
    'dhcp_lease_time',
    'dhcp_lps'
]

for metric in metrics:
    metric_value = getattr(src.ib, f"{metric}_stats")(servers_stats)
    csv_dict[metric] = metric_value
    
    src.common.write_log(f"{metric} = {metric_value}", verbose=True)
    
src.common.write_log(csv_dict, verbose=True)
#endregion /Print average metrics for all servers


#region Output to CSV file
src.common.dict_to_csv(csv_dict, ",")
src.common.dedup_file(os.environ['ib_output_file'])
#endregion /Output to CSV file


src.common.write_log(" ", verbose=True)
src.common.write_log(f"Report file available at: {os.environ['ib_output_file']}", verbose=True)
src.common.write_log(f"Log file available at: {os.environ['ib_log_file']}", verbose=True)
src.common.write_log("Script run finished.", verbose=True)