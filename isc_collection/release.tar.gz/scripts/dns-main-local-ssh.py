import sys, os, argparse, subprocess, json, datetime
import tabulate


#region Read version
version = open("./version.txt").read()
#endregion /Read version


#region Parse arguments
def comma_separated_list(value):
    return value.split(',')

parser = argparse.ArgumentParser()
parser.add_argument('-c', '--named-config-path', help='Path to the BIND config', required=False)
parser.add_argument('-s', '--servers', help='Remote servers list, split by commas.', type=comma_separated_list, required=False, default='10.10.6.31')
parser.add_argument('-o', '--output-file', help='Output file name', required=False, default=None)
parser.add_argument('-l', '--log-file', help='Log file name', required=False, default=None)
parser.add_argument('-v', '--version', help='Print version', action='store_true')
args = parser.parse_args()
#endregion /Parse arguments


#region Print version
if args.version:
    sys.path.append(".")
    import src.common
    src.common.print_version("DNS, Entry Point: local_from_ssh")
    sys.exit(0)
#endregion /Print version


#region Import helpers
sys.path.append(".")
import src.common, src.bind9, src.ssh, src.ib
print("")
from src import YELLOW, RED, RESET
#endregion /Import helpers


#region Set environment variables
os.environ['ib_datetime'] = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
os.environ['ib_root_directory'] = "/"
os.environ['ib_server_directory'] = "/"
os.environ['ib_ssh_mode'] = "True"

src.common.set_global_vars(args)
#endregion /Set environment variables


#region Print version
src.common.write_log(f"Script version: {version}", verbose=True)
src.common.write_log("Mode: locally process data getting them by ssh.", new_line=True, verbose=True)
#endregion /Print version


servers_stats = dict()


#region Loop through servers
for server in args.servers:
    src.common.write_log(f"Processing '{server}' server.", verbose=True)
    os.environ['ib_server'] = server
    
    
    #region Detect or use provided 'named.conf'
    if args.named_config_path is None:
        print("Detecting location of the BIND config file ... ", end="")
        src.common.write_log("Detecting location of the BIND config file.")
        os.environ['ib_named_config_path'] = src.bind9.get_config_path(os.environ['ib_server'])
        if os.environ['ib_named_config_path'] == "":
            src.common.write_log(f"{RED}Could not find location for BIND config file. Skipping server.{RESET}", severity="Warning", verbose=True)
            continue
        print("end.")
        src.common.write_log(f"found at location '{os.environ['ib_named_config_path']}'.", verbose=True)    
    else:
        os.environ['ib_named_config_path'] = args.named_config_path
        src.common.write_log(f"Using BIND configuration file '{os.environ['ib_named_config_path']}'.", verbose=True)
    #endregion /Detect or use provided 'named.conf'
    
    
    #region Parse config
    print("Parsing BIND config files... ", end = "")
    src.common.write_log("Parsing BIND config files.")
    bind_config = subprocess.run([
        ".venv/Scripts/python" if os.name == "nt" else ".venv/bin/python",
        "./tools/bind9_parser-0.99.3/dump-named-conf-json-ssh.py",
        "--root", os.environ['ib_root_directory'],
        "--server", server,
        os.environ['ib_named_config_path']
    ], capture_output=True, text=True
    )
    if bind_config.returncode != 0:
        src.common.write_log(f"{RED}Error while parsing BIND config:{RESET}", verbose=True, severity="Error")
        src.common.write_log(bind_config.stderr, verbose=True, severity="Error")
        src.common.write_log(bind_config.stdout, verbose=True, severity="Error")
        src.common.write_log("Skipping server.", verbose=True, severity="Error")
        continue
        
    try:
        bind_config = src.DictToObj(json.loads(bind_config.stdout))
    except Exception as e:
        src.common.write_log(f"{RED}Error while decoding parsed BIND config.{RESET}", verbose=True, severity="Error")
        src.common.write_log(bind_config, verbose=True, severity="Error")
        src.common.write_log("Skipping server.", verbose=True, severity="Error")
        continue
    print("done.")
    #endregion /Parse config
    
    
    #region Classify zones
    zones = src.bind9.get_server_zones(bind_config)
    src.bind9.print_zone_stats(zones)
    #endregion Classify zones
    
    
    #region Calculate metrics
    servers_stats[server] = dict()
    servers_stats[server]['gen_vendor'] = src.common.get_linux_version_from_file(server = os.environ['ib_server'])
    servers_stats[server]['dns_ext_forward_zone_count'] = src.ib.dns_ext_forward_zone_count(zones)
    servers_stats[server]['dns_ext_reverse_zone_count'] = src.ib.dns_ext_reverse_zone_count(zones)
    servers_stats[server]['dns_int_forward_zone_count'] = src.ib.dns_int_forward_zone_count(zones)
    servers_stats[server]['dns_int_reverse_zone_count'] = src.ib.dns_int_reverse_zone_count(zones)
    servers_stats[server]['dns_ext_record_count'] = src.ib.dns_ext_record_count(zones)
    servers_stats[server]['dns_int_record_count'] = src.ib.dns_int_record_count(zones)
    servers_stats[server]['dns_ext_server_count'] = src.ib.dns_ext_server_count(zones)
    servers_stats[server]['dns_int_server_count'] = src.ib.dns_int_server_count(zones)
    servers_stats[server]['dns_ext_dnssec_used'] = src.ib.dns_ext_dnssec_used(zones)
    servers_stats[server]['dns_int_dnssec_used'] = src.ib.dns_int_dnssec_used(zones)
    servers_stats[server]['dns_ext_ipv6_used'] = src.ib.dns_ext_ipv6_used(zones)
    servers_stats[server]['dns_int_ipv6_used'] = src.ib.dns_int_ipv6_used(zones)
    servers_stats[server]['dns_int_vendor'] = src.bind9.get_server_version(os.environ['ib_server']).strip()
    servers_stats[server]['dns_int_caching_forwarders'] = src.ib.dns_int_caching_forwarders(zones, bind_config)
    #endregion /Calculate metrics

#endregion /Loop through servers


#region Print raw metrics for all servers
src.common.write_log(" ", verbose=True)
src.common.write_log(servers_stats, verbose=True, new_line=True)
#endregion /Print raw metrics for all servers


#region Print average metrics for all servers
csv_dict = dict()

print("\n")
metrics = [
    'gen_vendor',
    'dns_ext_forward_zone_count',
    'dns_ext_reverse_zone_count',
    'dns_int_forward_zone_count',
    'dns_int_reverse_zone_count',
    'dns_ext_record_count',
    'dns_int_record_count',
    'dns_ext_server_count',
    'dns_int_server_count',
    'dns_ext_dnssec_used',
    'dns_int_dnssec_used',
    'dns_ext_ipv6_used',
    'dns_int_ipv6_used',
    'dns_int_vendor',
    'dns_int_caching_forwarders'
]

for metric in metrics:
    metric_value = getattr(src.ib, f"{metric}_stats")(servers_stats)
    csv_dict[metric] = metric_value
    
    src.common.write_log(f"{metric} = {metric_value}", verbose=True)
    
src.common.write_log(csv_dict, verbose=True)
#endregion /Print average metrics for all servers


#region Output to CSV file
src.common.dict_to_csv(csv_dict, ",")
src.common.dedup_file(os.environ['ib_output_file'])
#endregion /Output to CSV file


src.common.write_log(" ", verbose=True)
src.common.write_log(f"Report file available at: {os.environ['ib_output_file']}", verbose=True)
src.common.write_log(f"Log file available at: {os.environ['ib_log_file']}", verbose=True)
src.common.write_log("Script run finished.", verbose=True)