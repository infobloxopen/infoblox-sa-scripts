import sys, os, argparse, subprocess, json, datetime
import tabulate


#region Read version
version = open("./version.txt").read()
#endregion /Read version


#region Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument('-p', '--path', help='Path to the directory with configs', required=False, default="/home/udadzimau/mnt/")
# parser.add_argument('-s', '--server', help='DNS Server IP address', required=False, default=None)
parser.add_argument('-o', '--output-file', help='Output file name', required=False, default=None)
parser.add_argument('-l', '--log-file', help='Log file name', required=False, default=None)
parser.add_argument('-v', '--version', help='Print version', action='store_true')
args = parser.parse_args()
#endregion /Parse arguments


#region Print version
if args.version:
    sys.path.append(".")
    import src.common
    src.common.print_version("DHCP, Entry Point: local_from_mount")
    sys.exit(0)
#endregion /Print version


#region Import helpers
sys.path.append(".")
import src.common, src.dhcpd, src.ssh, src.ib
print("")
from src import YELLOW, RED, RESET
#endregion /Import helpers


#region Set environment variables
os.environ['ib_datetime'] = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
os.environ['ib_root_directory'] = args.path.rstrip("/")

src.common.set_global_vars(args)
#endregion /Set environment variables


#region Print version
src.common.write_log(f"Script version: {version}", verbose=True)
src.common.write_log("Mode: process data mounted to local server.", new_line=True, verbose=True)
#endregion /Print version


#region Find all servers to process
servers = [d for d in os.listdir(os.environ['ib_root_directory']) if os.path.isdir(os.path.join(os.environ['ib_root_directory'], d))]
src.common.write_log(f"Server folders found: '{servers}'.", verbose=True)
#endregion /Find all servers to process


servers_stats = dict()


#region Loop through servers
for server in servers:
    src.common.write_log(" ", verbose=True)
    src.common.write_log(f"Processing '{server}' server.", verbose=True)
    os.environ['ib_server'] = server
    
    
    #region Calculate paths
    os.environ['ib_server_directory'] = f"{os.environ['ib_root_directory']}/{os.environ['ib_server']}/"
    src.common.write_log(f"Server folder: '{os.environ['ib_server_directory']}'.", verbose=True)
    
    
    src.common.write_log(f"Looking for DHCPD config file in the mounted directory '{os.environ['ib_server_directory']}'.", verbose=True)
    dhcpd_config_possible_locations = [
        f"{os.environ['ib_server_directory']}etc/dhcp",
        f"{os.environ['ib_server_directory']}etc/dhcp3",
        f"{os.environ['ib_server_directory']}usr/local/etc",
        f"{os.environ['ib_server_directory']}usr/local/etc/dhcp"
    ]
    configs_found = 0
    for possible_dir in dhcpd_config_possible_locations:
        for root, dirs, files in os.walk(possible_dir):
            if "dhcpd.conf" in files and root in dhcpd_config_possible_locations:
                os.environ['ib_dhcpd_config_path'] = os.path.join(root, "dhcpd.conf")
                src.common.write_log(f"DHCPD config file found at '{os.environ['ib_dhcpd_config_path']}'.", verbose=True)
                configs_found += 1
            
    if configs_found > 1 or configs_found == 0:
        src.common.write_log(f"{RED}Config files found: {configs_found}. Required: 1. Skipping server.{RESET}", verbose=True, severity="Error")
        continue
    
    
    src.common.write_log(f"Looking for DHCPD leases file in the mounted directory '{os.environ['ib_server_directory']}'.", verbose=True)
    dhcpd_leases_possible_locations = [
        f"{os.environ['ib_server_directory']}var/lib/dhcp",
        f"{os.environ['ib_server_directory']}var/lib/dhcpd",
        f"{os.environ['ib_server_directory']}var/db/dhcpd",
        f"{os.environ['ib_server_directory']}var/state/dhcp",
        f"{os.environ['ib_server_directory']}var/lib/dhcp3",
        f"{os.environ['ib_server_directory']}etc/dhcp"
    ]
    leases_found = 0
    for possible_dir in dhcpd_leases_possible_locations:
        for root, dirs, files in os.walk(possible_dir):
            if "dhcpd.leases" in files and root in dhcpd_leases_possible_locations:
                os.environ['ib_dhcpd_leases_path'] = os.path.join(root, "dhcpd.leases")
                src.common.write_log(f"DHCPD leases file found at '{os.environ['ib_dhcpd_leases_path']}'.", verbose=True)
                leases_found += 1
            
    if leases_found > 1 or leases_found == 0:
        src.common.write_log(f"{RED}Leases files found: {leases_found}. Required: 1. Skipping server.{RESET}", verbose=True, severity="Error")
        continue
    #endregion /Calculate paths
    
    
    #region Parse config
    print("Parsing DHCPD config files... ", end = "")
    src.common.write_log("Parsing DHCPD config files.")
    dhcpd_config = src.dhcpd.parse_config(os.environ['ib_server_directory'], os.environ['ib_dhcpd_config_path'])
    print("done.")
    #endregion /Parse config
    
    
    #region Parse leases
    print("Parsing DHCPD leases file... ", end = "")
    src.common.write_log("Parsing DHCPD lease file.")
    dhcpd_leases = src.dhcpd.parse_leases(os.environ['ib_dhcpd_leases_path'])
    print("done.")
    #endregion /Parse leases
    
    
    #region Calculate metrics
    servers_stats[server] = dict()
    servers_stats[server]['gen_vendor'] = src.common.get_linux_version_from_file(server = os.environ['ib_server'], root_directory = os.environ['ib_server_directory'])
    servers_stats[server]['dhcp_vendor'] = src.dhcpd.get_server_version_from_file()
    servers_stats[server]['dhcp_server_count'] = src.ib.dhcp_server_count()
    servers_stats[server]['dhcp_subnet_count'] = src.ib.dhcp_subnet_count(dhcpd_config)
    servers_stats[server]['dhcp_device_count'] = src.ib.dhcp_device_count(dhcpd_config, dhcpd_leases)
    servers_stats[server]['dhcp_lease_time'] = src.ib.dhcp_lease_time(dhcpd_config)
    servers_stats[server]['dhcp_lps'] = src.ib.dhcp_lps(dhcpd_leases)
    #endregion /Calculate metrics

#endregion /Loop through servers


#region Print raw metrics for all servers
src.common.write_log(" ", verbose=True)
src.common.write_log(servers_stats, verbose=True, new_line=True)
#endregion /Print raw metrics for all servers


#region Print average metrics for all servers
csv_dict = dict()

print("\n")
metrics = [
    'gen_vendor',
    'dhcp_vendor',
    'dhcp_server_count',
    'dhcp_subnet_count',
    'dhcp_device_count',
    'dhcp_lease_time',
    'dhcp_lps'
]

for metric in metrics:
    metric_value = getattr(src.ib, f"{metric}_stats")(servers_stats)
    csv_dict[metric] = metric_value
    
    src.common.write_log(f"{metric} = {metric_value}", verbose=True)
    
src.common.write_log(csv_dict, verbose=True)
#endregion /Print average metrics for all servers


#region Output to CSV file
src.common.dict_to_csv(csv_dict, ",")
src.common.dedup_file(os.environ['ib_output_file'])
#endregion /Output to CSV file


src.common.write_log(" ", verbose=True)
src.common.write_log(f"Report file available at: {os.environ['ib_output_file']}", verbose=True)
src.common.write_log(f"Log file available at: {os.environ['ib_log_file']}", verbose=True)
src.common.write_log("Script run finished.", verbose=True)