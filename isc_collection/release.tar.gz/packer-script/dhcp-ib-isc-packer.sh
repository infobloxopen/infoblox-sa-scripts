#!/bin/bash


# Default values
CONF=""
OUT=""
LEASES=""


# Declare empty FIFO stacks
declare -a STACK


# Possible locations of dhcpd.conf
declare -a DHCPD_LOCS=(
"/etc/dhcp/"
"/etc/dhcp3/"
"/usr/local/etc/"
"/usr/local/etc/dhcp/"
)


# Possible locations of dhcpd.leases
declare -a DHCPD_LEASES_LOCS=(
"/var/lib/dhcp/"
"/var/db/dhcpd/"
"/var/state/dhcp"
"/var/lib/dhcp3"
"/etc/dhcp"
)


function get_os_release {
    while IFS= read -r line
    do
        if [[ $line =~ ^PRETTY_NAME=\"(.*)\"$ ]]; then
            echo "${BASH_REMATCH[1]}"
        fi
    done < /etc/os-release
}


# Function to recursively find all BIND config files
find_includes() {
    local file="$1"
    
    # Check if file exists and is readable
    if [[ -f "$file" && -r "$file" ]]; then
        # Read file line by line
        while IFS= read -r line || [[ -n "$line" ]]; do
        # Check if line matches 'include' pattern
        if [[ $line =~ ^[[:space:]]*(include)[[:space:]]+\"(.*)\"\; ]]; then
            # Get the included file
            local included_file="${BASH_REMATCH[2]}"
            
            # Add included file to stack
            STACK+=("$included_file")
            
            # Process included file
            find_includes "$included_file"
        fi
        done < "$file"
    fi
}


# Parse command line arguments
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --conf) CONF="$2"; shift ;;
        --leases) LEASES_PATH="$2"; shift ;;
        --out) OUT="$2"; shift ;;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done


# If OUT is empty, then set default output path
if [[ -z "$OUT" ]]; then
    COMPUTER_NAME=$(hostname)
    OUT="./dhcp-ib-isc-packer-$COMPUTER_NAME.tar.gz"
    echo "'out' parameter is not set. Setting to '$OUT'."
    echo " "
fi


# If 'conf' parameter is provided, add its value to FIFO stack.
# If 'conf' is not provided, look for the file 'dhcpd.conf' in all directories listed in DHCPD_LOCS array.
if [[ ! -z "$CONF" ]]; then
    STACK+=("$CONF")
    echo "DHCPD configuration root file set to '$CONF'."
else
    echo "'--conf' parameter is not set. Trying to locate it."
    for dir in "${DHCPD_LOCS[@]}"; do
        if [[ -e "${dir}dhcpd.conf" ]]; then
            CONF="${dir}dhcpd.conf"
            STACK+=("$CONF")
            echo "DHCPD configuration file found at: '$CONF'."
        fi
    done
fi


# If CONF is still empty, halt the script and ask to provide CONF parameter with path to 'dhcpd.conf' file.
if [[ -z "$CONF" ]]; then
    echo "Can't find the 'dhcpd.conf' file. Please provide '--conf' parameter with path to 'dhcpd.conf' file."
    exit 1
fi
echo " "


find_includes "$STACK"


#region Looking for 'dhcpd.leases' file
if [[ ! -z "$LEASES" ]]; then
    STACK+=("$LEASES")
    echo "DHCPD leases file set to '$LEASES'."
else
    echo "'--leases' parameter is not set. Trying to locate it."
    for dir in "${DHCPD_LEASES_LOCS[@]}"; do
        if [[ -e "${dir}dhcpd.leases" ]]; then
            LEASES="${dir}dhcpd.leases"
            STACK+=("$LEASES")
            echo "DHCPD leases file found at: '$LEASES'."
        fi
    done
fi
#endregion Looking for 'dhcpd.leases' file


# Getting IP address
IP=$(ip addr show 2>/dev/null | grep -o 'inet [0-9]\+\.[0-9]\+\.[0-9]\+\.[0-9]\+' | grep -v 127.0.0.1 | awk '{print $2}')

if [ -z "$IP" ]; then
    # If ip command failed, try to use ifconfig
    IP=$(ifconfig 2>/dev/null | grep -o 'inet addr:[0-9]\+\.[0-9]\+\.[0-9]\+\.[0-9]\+' | grep -v 127.0.0.1 | awk -F: '{print $2}')
fi

if [ -z "$IP" ]; then
    echo "Could not determine IP address."
fi
echo "$COMPUTER_NAME" >> ./dhcp-ib-isc-packer-details.txt
echo "$IP" >> ./dhcp-ib-isc-packer-details.txt
dhcpd --version 2>> ./dhcp-ib-isc-packer-details.txt
get_os_release >> ./dhcp-ib-isc-packer-details.txt


# Show values (for debug purposes)
echo " "
echo "CONF: $CONF"
echo "LEASES: $LEASES"
echo "OUT: $OUT"
echo "IP: $IP"


echo " "
echo "STACK:"
printf '%s\n' "${STACK[@]}"


echo ""
echo "Putting files to '$OUT' archive."
STACK+=("dhcp-ib-isc-packer-details.txt")
FILES=("${STACK[@]}")
tar -czf $OUT "${FILES[@]}"

rm dhcp-ib-isc-packer-details.txt