#!/bin/bash


# Default values
CONF=""
DIRECTORY=""
OUT=""


# Declare empty FIFO stacks
declare -a STACK
declare -a ZONES


# Possible locations of named.conf
declare -a NAMED_LOCS=(
"/etc/"
"/etc/bind/"
"/etc/bind9/"
"/etc/namedb/"
"/usr/local/etc/namedb/"
"/etc/named/"
"/var/named/"
"/var/named/etc/"
"/usr/local/etc/named/"
"/usr/local/bind9/"
"/usr/local/bind9/etc/"
"/var/bind9/etc/"
"/var/bind9/lib/etc/"
"/var/lib/bind9/"
"/var/lib/bind9/etc/"
"/opt/etc/"
"/opt/bind9/etc/"
"/opt/etc/bind9/"
"/opt/etc/namedb/"
"/opt/etc/named/"
)


function get_os_release {
    while IFS= read -r line
    do
        if [[ $line =~ ^PRETTY_NAME=\"(.*)\"$ ]]; then
            echo "${BASH_REMATCH[1]}"
        fi
    done < /etc/os-release
}


# Function to recursively find all BIND config files
find_includes() {
    local file="$1"
    
    # Check if file exists and is readable
    if [[ -f "$file" && -r "$file" ]]; then
        # Read file line by line
        while IFS= read -r line || [[ -n "$line" ]]; do
        # Check if line matches 'include' pattern
        if [[ $line =~ ^[[:space:]]*(include)[[:space:]]+\"(.*)\"\; ]]; then
            # Get the included file
            local included_file="${BASH_REMATCH[2]}"
            
            # Add included file to stack
            STACK+=("$included_file")
            
            # Process included file
            find_includes "$included_file"
        fi
        done < "$file"
    fi
}


# Function to find zones in a file
find_zones() {
    local file="$1"
    local in_zone_block=false

    # Check if file exists and is readable
    if [[ -f "$file" && -r "$file" ]]; then
        # Read file line by line
        while IFS= read -r line || [[ -n "$line" ]]; do
            # Check if line matches 'zone' pattern
            if [[ $line =~ ^(zone)[[:space:]]+\"(.+)\"(.+)\{ ]]; then
                in_zone_block=true
            # Check if line matches 'file' pattern
            elif [[ $in_zone_block = true && $line =~ ^[[:space:]]+(file)[[:space:]]+\"(.*)\"\; ]]; then
                # Get the zone file
                local zone_file="${BASH_REMATCH[2]}"

                # Check if zone_file is abosolute or relative path
                if [[ $zone_file != /* ]]; then
                    zone_file="$DIRECTORY/$zone_file"
                fi

                # Add zone file to ZONES stack
                ZONES+=("$zone_file")
            # Check if line matches '};' pattern
            elif [[ $in_zone_block = true && $line =~ \}\; ]]; then
                in_zone_block=false
            fi
        done < "$file"
    fi
}


# Parse command line arguments
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --conf) CONF="$2"; shift ;;
        --directory) DIRECTORY="$2"; shift ;;
        --out) OUT="$2"; shift ;;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done


# If OUT is empty, then set default output path
if [[ -z "$OUT" ]]; then
    COMPUTER_NAME=$(hostname)
    OUT="./dns-ib-isc-packer-$COMPUTER_NAME.tar.gz"
    echo "'out' parameter is not set. Setting to '$OUT'."
    echo " "
fi


# If 'conf' parameter is provided, add its value to FIFO stack.
# If 'conf' is not provided, look for the file 'named.conf' in all directories listed in NAMED_LOCS array.
if [[ ! -z "$CONF" ]]; then
    STACK+=("$CONF")
    echo "BIND configuration root file set to '$CONF'."
else
    echo "'conf' parameter is not set. Trying to locate it."
    for dir in "${NAMED_LOCS[@]}"; do
        if [[ -e "${dir}named.conf" ]]; then
            CONF="${dir}named.conf"
            STACK+=("$CONF")
            echo "BIND configuration file found at: '$CONF'."
        fi
    done
fi


# If CONF is still empty, halt the script and ask to provide CONF parameter with path to 'named.conf' file.
if [[ -z "$CONF" ]]; then
    echo "Can't find the 'named.conf' file. Please provide '--conf' parameter with path to 'named.conf' file."
    exit 1
fi
echo " "


find_includes "$STACK"


# If DIRECTORY variable is empty
if [[ -z "$DIRECTORY" ]]; then
    echo "'directory' parameter is not set. Parsing BIND configuration files to locate it."
    # Look for the 'directory' string in all files in STACK
    for file in "${STACK[@]}"; do
        if [[ -f "$file" && -r "$file" ]]; then
        while IFS= read -r line; do
            # Check if line matches 'directory' pattern
            if [[ $line =~ ^[[:space:]]+(directory)[[:space:]]+\"(.*)\"\;$ ]]; then
            # Get the directory
            DIRECTORY="${BASH_REMATCH[2]}"
            echo "BIND working directory found at: '$DIRECTORY'."
            break 2
            fi
        done < "$file"
        fi
    done
fi


# If DIRECTORY is still empty, halt the script and ask to provide DIRECTORY parameter.
if [[ -z "$DIRECTORY" ]]; then
    echo "Can't find the 'directory' string in configuration files. Please provide '--directory' parameter."
    echo "STACK:"
    printf '%s\n' "${STACK[@]}"
    exit 1
fi


# Find zones in BIND config
for file in "${STACK[@]}"; do
    find_zones "$file"
done


# Remove possible duplicated files from ZONES
# Read the array values into a hash map
declare -A map
for zone in "${ZONES[@]}"; do
  map["$zone"]=1
done

# Read the keys from the hash map back into the array
ZONES=("${!map[@]}")

# Print the array to verify duplicates are removed
echo "${ZONES[@]}"


# Getting IP address
IP=$(ip addr show 2>/dev/null | grep -o 'inet [0-9]\+\.[0-9]\+\.[0-9]\+\.[0-9]\+' | grep -v 127.0.0.1 | awk '{print $2}')

if [ -z "$IP" ]; then
    # If ip command failed, try to use ifconfig
    IP=$(ifconfig 2>/dev/null | grep -o 'inet addr:[0-9]\+\.[0-9]\+\.[0-9]\+\.[0-9]\+' | grep -v 127.0.0.1 | awk -F: '{print $2}')
fi

if [ -z "$IP" ]; then
    echo "Could not determine IP address."
fi
echo "$COMPUTER_NAME" >> ./dns-ib-isc-packer-details.txt
echo "$IP" >> ./dns-ib-isc-packer-details.txt
named -v >> ./dns-ib-isc-packer-details.txt
get_os_release >> ./dns-ib-isc-packer-details.txt



# Show values (for debug purposes)
echo " "
echo "CONF: $CONF"
echo "DIRECTORY: $DIRECTORY"
echo "OUT: $OUT"
echo "IP: $IP"


echo " "
echo "STACK:"
printf '%s\n' "${STACK[@]}"

echo " "
echo "ZONES:"
printf '%s\n' "${ZONES[@]}"


echo ""
echo "Putting files to '$OUT' archive."
STACK+=("dns-ib-isc-packer-details.txt")
FILES=("${STACK[@]}" "${ZONES[@]}")
tar -czf $OUT "${FILES[@]}"

rm dns-ib-isc-packer-details.txt