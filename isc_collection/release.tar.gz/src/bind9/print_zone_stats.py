import tabulate
import src.common, src.bind9
from src import YELLOW, RED, RESET, DictToObj


def print_zone_stats(
    zones: list
) -> None:
    ###
    
    if len(zones) > 0:
        headers = list(zones[next(iter(zones))]['zone_statistics'].keys())
        rows = []
        for key, value in zones.items():
            rows.append(list(value['zone_statistics'].values()))
            
        src.common.write_log(f"\n{tabulate.tabulate(rows, headers=headers, tablefmt='pretty')}", verbose=True)
    else:
        src.common.write_log(f"No zones found in the BIND config.", verbose=True)