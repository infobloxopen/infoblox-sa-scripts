import re
import dns.zone, dns.rdatatype
import src.common, src.bind9
from src import YELLOW, RED, RESET, DictToObj


def classify_zone(
    zone: dns.zone,
    ext_int_ratio: float = 0.3,
    ipv6_ratio: float = 0.3
) -> DictToObj:
    ###
    
    src.common.write_log(f"Classifying '{str(zone.origin)}' zone.", verbose=True)
    
    
    privateIpv4Ranges = re.compile(r"(^127\.)|(^10\.)|(^172\.1[6-9]\.)|(^172\.2[0-9]\.)|(^172\.3[0-1]\.)|(^192\.168\.)")
    privateIpv6Ranges = re.compile(r"^f[cd][0-9a-fA-F]{2}:") # fc00::/7
    localIpv6Ranges = re.compile(r"^fe[89abAB][0-9a-fA-F]:") # fe80::/10
    
    
    result = dict()
    
    
    #region Add properties to the object
    result['name'] = str(zone.origin)
    
    result['is_rev'] = None
    result['is_ext'] = None
    result['is_int'] = None
    result['is_ipv6'] = None
    result['is_dnssec'] = None
    
    result['rec_cnt'] = None
    result['ext_ipv4_cnt'] = None
    result['int_ipv4_cnt'] = None
    result['ext_ipv6_cnt'] = None
    result['int_ipv6_cnt'] = None
    result['loc_ipv6_cnt'] = None
    result['ext_rev_cnt'] = None
    result['int_rev_cnt'] = None
    #endregion /Add properties to the object
    
    
    #region rec_cnt
    tmp = []
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype in [dns.rdatatype.A, dns.rdatatype.AAAA, dns.rdatatype.PTR]:
                for rdata in rdataset:
                    tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['rec_cnt'] = len(tmp)
    #endregion /rec_cnt
    
    
    #region ext_ipv4_cnt
    tmp = []
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype == dns.rdatatype.A:
                for rdata in rdataset:
                    if not privateIpv4Ranges.match(str(rdata)):
                        tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['ext_ipv4_cnt'] = len(tmp)
    #endregion /ext_ipv4_cnt
    
    
    #region int_ipv4_cnt
    tmp = []
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype == dns.rdatatype.A:
                for rdata in rdataset:
                    if privateIpv4Ranges.match(str(rdata)):
                        tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['int_ipv4_cnt'] = len(tmp)
    #endregion /int_ipv4_cnt
    
    
    #region ext_ipv6_cnt
    tmp = []
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype == dns.rdatatype.AAAA:
                for rdata in rdataset:
                    if not privateIpv6Ranges.match(str(rdata)) and not localIpv6Ranges.match(str(rdata)):
                        tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['ext_ipv6_cnt'] = len(tmp)
    #endregion /ext_ipv6_cnt
    
    
    #region int_ipv6_cnt
    tmp = []
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype == dns.rdatatype.AAAA:
                for rdata in rdataset:
                    if privateIpv6Ranges.match(str(rdata)) and not localIpv6Ranges.match(str(rdata)):
                        tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['int_ipv6_cnt'] = len(tmp)
    #endregion /int_ipv6_cnt
    
    
    #region loc_ipv6_cnt
    tmp = []
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype == dns.rdatatype.AAAA:
                for rdata in rdataset:
                    if not privateIpv6Ranges.match(str(rdata)) and localIpv6Ranges.match(str(rdata)):
                        tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['loc_ipv6_cnt'] = len(tmp)
    #endregion /loc_ipv6_cnt
    
    
    #region is_dnssec
    tmp = []
    dnssec_record_types = [
        dns.rdatatype.NSEC,
        dns.rdatatype.NSEC3,
        dns.rdatatype.RRSIG,
        dns.rdatatype.DNSKEY,
        dns.rdatatype.DS,
        dns.rdatatype.CDNSKEY,
        dns.rdatatype.CDS,
        dns.rdatatype.NSEC3PARAM
    ]
    for name, node in zone.nodes.items():
        for rdataset in node.rdatasets:
            if rdataset.rdtype in dnssec_record_types:
                for rdata in rdataset:
                    tmp.append({'name' : str(name), 'rdata' : str(rdata)})
    result['is_dnssec'] = True if len(tmp) > 0 else False
    #endregion /is_dnssec
    
    
    #region If the zone is reverse
    if src.bind9.is_reverse_zone(str(zone.origin)):
        result['is_rev'] = True
        
        
        zone_prefix = '.'.join(str(zone.origin).replace(".in-addr.arpa.", "").split(".")[::-1]) + "."
        
        
        #region ext_rev_cnt
        tmp = []
        if not privateIpv4Ranges.match(zone_prefix):
            for name, node in zone.nodes.items():
                for rdataset in node.rdatasets:
                    if rdataset.rdtype == dns.rdatatype.PTR:
                        for rdata in rdataset:
                            tmp.append({'name' : str(name), 'rdata' : str(rdata)})
        result['ext_rev_cnt'] = len(tmp)
        #endregion /ext_rev_cnt
        
        
        #region int_rev_cnt
        tmp = []
        if privateIpv4Ranges.match(zone_prefix):
            for name, node in zone.nodes.items():
                for rdataset in node.rdatasets:
                    if rdataset.rdtype == dns.rdatatype.PTR:
                        for rdata in rdataset:
                            tmp.append({'name' : str(name), 'rdata' : str(rdata)})
        result['int_rev_cnt'] = len(tmp)
        #endregion /int_rev_cnt
    #endregion /If the zone is reverse
    #region If the zone is forward
    else:
        result['is_rev'] = False
        result['int_rev_cnt'] = 0
        result['ext_rev_cnt'] = 0
    #endregion /If the zone is forward
    
    
    #region Classifying zone
    is_external_ratio = (result['ext_ipv4_cnt'] + result['ext_ipv6_cnt'] + result['ext_rev_cnt']) / (result['rec_cnt'] + 0.0000001)
    result['is_ext'] = is_external_ratio >= ext_int_ratio
    
    result['is_int'] = is_external_ratio < ext_int_ratio
    
    is_ipv6_ratio = (result['ext_ipv6_cnt'] + result['int_ipv6_cnt']) / (result['rec_cnt'] + 0.0000001)
    result['is_ipv6'] = is_ipv6_ratio >= ipv6_ratio
    #endregion /Classifying zone
    
    
    return result