import os
import dns.zone
from src import YELLOW, RED, RESET, DictToObj
import src.ssh



def get_zone(
    bind_config: DictToObj,
    zone_name: str = None,
    get_zone_content: bool = False
):
    ###
    
    # Zone names to filter out, because they're built-in
    builtin_zones = [
        "localhost.localdomain",
        "localhost",
        ".",
        "1.0.0.127.in-addr.arpa",
        "0.in-addr.arpa",
        "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa",
        "127.in-addr.arpa",
        "0.in-addr.arpa",
        "255.in-addr.arpa",
    ]
    # /Zone names to filter out, because they're built-in
    
    
    # If no specific zone name is provided
    if zone_name is None:
        result = [zone for zone in bind_config.zones if zone.zone_name not in builtin_zones]
        
        return result
    # /If no specific zone name is provided
    # If specific zone name is provided
    else:
        zone = next((zone for zone in bind_config.zones if zone.zone_name == zone_name), None)
        
        if get_zone_content:
            if os.environ.get('ib_ssh_mode') is not None:
                if os.environ['ib_ssh_mode'] == "True":
                    file_content = src.ssh.invoke_command(os.environ['ib_server'], f"cat {os.environ['ib_server_directory']}/{zone.file}")
            else:
                file_content = open(f"{os.environ['ib_server_directory']}/{zone.file}", "r").read()
                
            zone_content = dns.zone.from_text(file_content, zone_name)
            
            return zone_content
        
        return zone
    # /If specific zone name is provided