import os, subprocess, re
import src.ssh, src.common
from src import YELLOW, RED, RESET


def get_config_path(
    server: str    
) -> str:
    ###
    src.common.write_log(f"Detecting BIND config file location.", verbose=True)
    
    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            result = src.ssh.invoke_command(server, 'named -V')
    else:
        result = subprocess.run(['named', '-V'], stdout=subprocess.PIPE)
        result = result.stdout.decode('utf-8')
    
    match = re.search(r'named configuration:\s*(\S+)', result)
    
    
    if match:
        return match.group(1)
    else:
        src.common.write_log(f"{RED}Could not find BIND config file.{RESET}", severity="Error", verbose=True)
        return ""