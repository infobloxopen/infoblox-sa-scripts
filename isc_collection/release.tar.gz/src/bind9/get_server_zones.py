from src import YELLOW, RED, RESET, DictToObj
import src.bind9


def get_server_zones(
    bind_config: DictToObj,
) -> list:
    ###
    
    result = dict()
    
    
    zones = src.bind9.get_zone(bind_config)


    for zone in zones:
        if zone.type != "forward":
            zone_content = src.bind9.get_zone(bind_config, zone_name=zone.zone_name, get_zone_content = True)
            zone_properties = src.bind9.classify_zone(zone_content)
            
            result[zone.zone_name] = {
                'type' : zone.type,
                'zone_content' : zone_content,
                'zone_statistics' : zone_properties
            }
        elif zone.type == "forward":
            zone_properties = src.bind9.classify_null_zone(zone.zone_name, {})
            result[zone.zone_name] = {
                'type' : zone.type,
                'zone_content' : None,
                'zone_statistics' : zone_properties,
            }
        
    return result