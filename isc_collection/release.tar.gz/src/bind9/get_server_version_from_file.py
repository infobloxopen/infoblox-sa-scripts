import subprocess, os, re
import src.common


def get_server_version_from_file(
    root_directory: str = ""
) -> str:
    ###
    
    src.common.write_log("Trying to detect BIND server version from filesystem.", verbose=True)
    
    possible_locations = [
        f"{root_directory}/usr/sbin/named",
        f"{root_directory}/usr/local/sbin/named",
        f"{root_directory}/sbin/named",
        f"{root_directory}/usr/bin/named"
    
    ]
    
    bind_version_pattern = re.compile(r'^named version: (.*)$')


    for location in possible_locations:
        if os.path.exists(location):
            try:
                result = subprocess.check_output(["strings", location])
                lines = result.decode("utf-8").split('\n')
                for line in lines:
                    match = bind_version_pattern.match(line)
                    if match:
                        return match.group(1)
            except:
                pass

    return "BIND version not found."