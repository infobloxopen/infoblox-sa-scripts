import dns.zone


def is_reverse_zone(
    zone_name
) -> bool:
    ###
    
    zone = dns.name.from_text(zone_name)
    
    return zone.is_subdomain(dns.name.from_text('in-addr.arpa.')) or \
           zone.is_subdomain(dns.name.from_text('ip6.arpa.'))