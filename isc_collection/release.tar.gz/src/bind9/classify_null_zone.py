import dns.zone
import src.common, src.bind9
from src import YELLOW, RED, RESET, DictToObj


def classify_null_zone(
    zone_name: str,
    zone: dict
) -> DictToObj:
    ###
    
    src.common.write_log(f"Classifying '{zone_name}' zone.", verbose=True)
    
    
    result = dict()
    
    
    #region Add properties to the object
    result['name'] = zone_name
    
    result['is_rev'] = None
    result['is_ext'] = None
    result['is_int'] = None
    result['is_ipv6'] = None
    result['is_dnssec'] = None
    
    result['rec_cnt'] = 0
    result['ext_ipv4_cnt'] = 0
    result['int_ipv4_cnt'] = 0
    result['ext_ipv6_cnt'] = 0
    result['int_ipv6_cnt'] = 0
    result['loc_ipv6_cnt'] = 0
    result['ext_rev_cnt'] = 0
    result['int_rev_cnt'] = 0
    #endregion /Add properties to the object
    
    
    return result