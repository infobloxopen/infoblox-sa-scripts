from src import YELLOW, RED, RESET


def dhcp_subnet_count(
    dhcpd_config: dict
) -> int:
    ###
    
    count = 0
    for key in dhcpd_config.keys():
        if key.startswith('subnet'):
            count += 1
            
    return count


#region Statistics function
def dhcp_subnet_count_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = sum(value['dhcp_subnet_count'] for value in servers_stats.values())
    
    return result
#endregion /Statistics function