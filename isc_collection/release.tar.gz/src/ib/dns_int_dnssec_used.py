from src import YELLOW, RED, RESET, DictToObj


def dns_int_dnssec_used(
    zones: DictToObj
) -> int:
    ###
    
    dnssec_zones = sum(1 for value in zones.values() if value['zone_statistics']['is_dnssec'] and not value['zone_statistics']['is_ext'])
    result = 1 if dnssec_zones > 0 else 0
    
    return result


#region Statistics function
def dns_int_dnssec_used_stats(
    servers_stats: dict
) -> str:
    ###
    
    dnssec_servers = sum(value['dns_int_dnssec_used'] for value in servers_stats.values())
    result = 1 if dnssec_servers > 0 else 0
    
    return result
#endregion /Statistics function