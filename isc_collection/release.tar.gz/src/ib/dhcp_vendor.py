from src import YELLOW, RED, RESET, DictToObj


#region Statistics function
def dhcp_vendor_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = ";".join([value['dhcp_vendor'] for value in servers_stats.values()])
    
    return result
#endregion /Statistics function