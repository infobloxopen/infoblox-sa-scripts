from src import YELLOW, RED, RESET, DictToObj


def dhcp_device_count(
    dhcpd_config: dict,
    dhcpd_leases: list
) -> int:
    ###
    
    #region Count leases
    macs = [lease.ethernet for lease in dhcpd_leases]
    leases_count = len(list(set(macs)))
    #endregion /Count leases
    
    
    #region Count reservations
    reservations_count = 0
    for key in dhcpd_config.keys():
        if key.startswith('host') and 'fixed-address' in dhcpd_config[key]:
            reservations_count += 1
    #endregion /Count reservations
    
    return leases_count + reservations_count


#region Statistics function
def dhcp_device_count_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = sum(value['dhcp_device_count'] for value in servers_stats.values())
    
    return result
#endregion /Statistics function