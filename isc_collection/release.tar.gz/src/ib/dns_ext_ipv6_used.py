from src import YELLOW, RED, RESET, DictToObj


def dns_ext_ipv6_used(
    zones: DictToObj
) -> int:
    ###
    
    ipv6_zones = sum(1 for value in zones.values() if value['zone_statistics']['is_ipv6'] and value['zone_statistics']['is_ext'])
    result = 1 if ipv6_zones > 0 else 0
    
    return result


#region Statistics function
def dns_ext_ipv6_used_stats(
    servers_stats: dict
) -> str:
    ###
    
    ipv6_servers = sum(value['dns_ext_ipv6_used'] for value in servers_stats.values())
    result = 1 if ipv6_servers > 0 else 0
    
    return result
#endregion /Statistics function