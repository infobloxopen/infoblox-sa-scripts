from src import YELLOW, RED, RESET, DictToObj


def dhcp_server_count() -> int:
    ###
    
    return 1


#region Statistics function
def dhcp_server_count_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = sum(value['dhcp_server_count'] for value in servers_stats.values())
    
    return result
#endregion /Statistics function