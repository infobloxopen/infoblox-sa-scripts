from src import YELLOW, RED, RESET, DictToObj
from datetime import datetime, timedelta, timezone


def dhcp_lps(
    dhcpd_leases: list,
    last_hours: int = 3
) -> float:
    ###
    
    
    #region Get leases for last 'last_hours hours
    now = datetime.now(timezone.utc)
    last_leases = [dhcpd_lease for dhcpd_lease in dhcpd_leases if dhcpd_lease.start >= now - timedelta(hours = last_hours)]
    #endregion /Get leases for 'last_hours hours
    
    
    if len(last_leases) > 0:
        delta = last_leases[-1].start - last_leases[0].start
        result = round(len(last_leases) / delta.seconds, 6)
    else:
        result = 0
    
    
    return result
    

#region Statistics function
def dhcp_lps_stats(
    servers_stats: dict
) -> str:
    ###
    
    values = [value['dhcp_lps'] for value in servers_stats.values()]
    result = round(sum(values) / len(values), 6)
    
    return result
#endregion /Statistics function