from src import YELLOW, RED, RESET, DictToObj


def dns_ext_record_count(
    zones: DictToObj
) -> int:
    ###
    
    result = sum([value['zone_statistics']['rec_cnt'] for value in zones.values() if value['zone_statistics']['is_ext']])
    
    return result


#region Statistics function
def dns_ext_record_count_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = sum(value['dns_ext_record_count'] for value in servers_stats.values())
    
    return result
#endregion /Statistics function