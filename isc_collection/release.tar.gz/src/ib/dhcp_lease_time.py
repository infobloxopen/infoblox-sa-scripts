from src import YELLOW, RED, RESET, DictToObj
import src.common


def dhcp_lease_time(
    dhcpd_config: dict
) -> float:
    ###

    lease_times = []
    
    for key in dhcpd_config.keys():
        if key.startswith('subnet'):
            if 'default-lease-time' in dhcpd_config[key]:
                lease_times.append(int(dhcpd_config[key]['default-lease-time']))
            elif 'default-lease-time' in dhcpd_config:
                lease_times.append(int(dhcpd_config['default-lease-time']))
            else:
                src.common.write_log(f"{RED}Error while trying to calculate 'dhcp_lease_time' metric. Check that config files have 'default-lease-time' option.{RESET}", severity="Error", verbose=True)
                return 0

    if len(lease_times) > 0:
        result = int(sum(lease_times) / len(lease_times))
    else:
        result = 0
        
    return result


#region Statistics function
def dhcp_lease_time_stats(
    servers_stats: dict
) -> str:
    ###
    
    values = [value['dhcp_lease_time'] for value in servers_stats.values() if value['dhcp_lease_time'] != 0]
    result = round(sum(values) / len(values))
    
    return result
#endregion /Statistics function