from src import YELLOW, RED, RESET, DictToObj


def dns_ext_server_count(
    zones: DictToObj
) -> int:
    ###
    
    ext_zones = sum(1 for value in zones.values() if value['zone_statistics']['is_ext'])
    if ext_zones > 0:
        result = 1
    else:
        result = 0
    
    
    return result


#region Statistics function
def dns_ext_server_count_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = sum(value['dns_ext_server_count'] for value in servers_stats.values())
    
    return result
#endregion /Statistics function