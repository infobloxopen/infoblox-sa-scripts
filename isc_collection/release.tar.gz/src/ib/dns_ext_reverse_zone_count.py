from src import YELLOW, RED, RESET, DictToObj


def dns_ext_reverse_zone_count(
    zones: DictToObj
) -> int:
    ###
    
    result = len([value for value in zones.values() if value['zone_statistics']['is_rev'] and value['zone_statistics']['is_ext']])
    
    return result


#region Statistics function
def dns_ext_reverse_zone_count_stats(
    servers_stats: dict
) -> str:
    ###
    
    result = sum(value['dns_ext_reverse_zone_count'] for value in servers_stats.values())
    
    return result
#endregion /Statistics function