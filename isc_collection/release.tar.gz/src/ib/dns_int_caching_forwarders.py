from src import YELLOW, RED, RESET, DictToObj


def dns_int_caching_forwarders(
    zones: DictToObj,
    bind_config: DictToObj
) -> int:
    ###
    
    forward_zones_count = sum(1 for value in zones.values() if value['type'] == "forward")
    server_forwarders_count = 0
    if hasattr(bind_config.options[0], 'forwarders'):
        if hasattr(bind_config.options[0].forwarders, 'forwarder'):
            server_forwarders_count = len(bind_config.options[0].forwarders.forwarder)
    result = 1 if forward_zones_count > 0 or server_forwarders_count > 0 else 0
    
    return result


#region Statistics function
def dns_int_caching_forwarders_stats(
    servers_stats: dict
) -> str:
    ###
    
    forwarding_servers = sum(value['dns_int_caching_forwarders'] for value in servers_stats.values())
    result = 1 if forwarding_servers > 0 else 0
    
    return result
#endregion /Statistics function