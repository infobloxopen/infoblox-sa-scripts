import subprocess
from src import YELLOW, RED, RESET
import src.common


def invoke_command(
    server: str,
    command: str
) -> str:
    ###
    
    try:
        src.common.write_log(f"Executing '{command}' command over SSH on the '{server}' server.", verbose=True)
        output = subprocess.check_output(
            [
                "ssh",
                server,
                command
            ],
            stderr=subprocess.STDOUT
        )
        return output.decode().strip('\n')
    
    except subprocess.CalledProcessError as e:
        src.common.write_log(f"{RED}Command '{command}' failed on host '{server}' with error: {e}.{RESET}", severity="Error", verbose=True)
        return None
    except Exception as e:
        src.common.write_log(f"{RED}An unknown error occurred while trying to run '{command}' on host '{server}': {e}.{RESET}", severity="Error", verbose=True)
        return None