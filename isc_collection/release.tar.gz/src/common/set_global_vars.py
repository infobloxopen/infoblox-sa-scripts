import os


def set_global_vars(
    global_args
) -> None:
    ###
    
    os.environ['ib_log_directory'] = "./@logs"
    os.environ['ib_output_directory'] = "./@output"


    if global_args.output_file == None:
        os.environ['ib_output_file'] = f"{os.environ['ib_output_directory']}/{os.environ['ib_datetime']}.csv"
    else:
        os.environ['ib_output_file'] = global_args.output_file
        
    if global_args.log_file == None:
        os.environ['ib_log_file'] = f"{os.environ['ib_log_directory']}/{os.environ['ib_datetime']}.log"
    else:
        os.environ['ib_log_file'] = global_args.log_file