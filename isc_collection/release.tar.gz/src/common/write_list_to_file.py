from typing import List
from src import YELLOW, RED, RESET


def write_list_to_file(
    strings: List[str],
    filename: str
) -> None:
    ###
    try:
        with open(filename, 'a', encoding='utf-8') as file:
            if strings is not None:
                for string in strings:
                    string = string.replace('\t', '    ')
                    file.write(string + '\n')
                
    except FileNotFoundError:
        print(f"{RED}Error: File '{filename}' not found.{RESET}")
        
    except PermissionError:
        print(f"{RED}Error: Permission denied to write to '{filename}'.{RESET}")
        
    except Exception as e:
        print(f"{RED}Error: {e}.{RESET}")
        
    finally:
        file.close()