import os, re
import src.ssh
import src.common


def get_linux_version_from_file(
    server: str,
    root_directory: str = ""
) -> str:
    ###
    
    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            file_list = [
                f"{root_directory}/etc/os-release"
            ]
            
            for file in file_list:
                regex = r'^PRETTY_NAME="(.*)"$'
                output = src.ssh.invoke_command(server, f"cat {file}")
                for line in output.split('\n'):
                    match = re.search(regex, line)
                    if match:
                        return match.group(1)
            
            
            file_list = [
                "/etc/redhat-release",
                "/etc/lsb-release",
                "/etc/debian_version"
            ]
            
            for file in file_list:
                output = src.ssh.invoke_command(server, f"cat {file}")
                file_content = output.replace('\n', '; ')
                return file_content
            
    else:
        file_list = [
            f"{root_directory}/etc/os-release"
        ]
        
        for file in file_list:
            regex = r'^PRETTY_NAME="(.*)"$'
            try:
                with open(file, 'r') as f:
                    for line in f:
                        match = re.search(regex, line)
                        if match:
                            return match.group(1)
            except FileNotFoundError:
                continue
        
        
        
        file_list = [
            f"{root_directory}/etc/redhat-release",
            f"{root_directory}/etc/lsb-release",
            f"{root_directory}/etc/debian_version"
        ]
        
        for file in file_list:
            try:
                with open(file, 'r') as f:
                    file_content = f.read()
                    file_content = file_content.replace('\n', '; ')
                    return file_content
            except FileNotFoundError:
                continue
        
    
    src.common.write_log(f"Failing to get Linux version for the '{server}' server using filesystem.", severity="Warning", verbose=True)
    return ''