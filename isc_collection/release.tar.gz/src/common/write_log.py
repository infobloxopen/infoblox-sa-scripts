import os, datetime
from src import YELLOW, RED, RESET


def write_log(
    text: str,
    new_line: bool = False,
    severity: str = "Info",
    verbose: bool = False
) -> None:
    ###
    
    #region Create folder
    if not os.path.exists(os.environ['ib_log_directory']):
        os.makedirs(os.environ['ib_log_directory'])
    #endregion /Create folder
    
    
    #region Format spaces
    severity_length = len(severity)
    if severity_length <= 7:
        severity_stamp = f"[{severity}]"
        for i in range(severity_length, 10):
            severity_stamp += " "
    #endregion /Format spaces
    
    
    #region Write to log
    try:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S->") + str(datetime.datetime.now().microsecond // 1000)
        
        with open(os.environ['ib_log_file'], 'a') as file:
            formatted_text = str(text).replace('\033[91m', '').replace('\033[33m', '').replace('\033[0m', '')
            file.write(f"{timestamp} {severity_stamp} {formatted_text}\n")
            if new_line:
                file.write("\n")
            
    except Exception as e:
        print(f"{RED}An error occurred while writing to the file: {e}.{RESET}")
        print(f"{RED}Considering as halting failure and exiting.{RESET}")
        exit(1)
    #endregion /Write to log

    
    #region Output the same
    if verbose:
        print(text)
        if new_line:
            print()
    #endregion /Output the same