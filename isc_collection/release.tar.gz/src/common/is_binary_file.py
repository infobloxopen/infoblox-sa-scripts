from src import YELLOW, RED, RESET


def is_binary_file(
    file_path: str
) -> bool:
    ###
    
    with open(file_path, 'rb') as file:
        for chunk in file:
            if b'\0' in chunk:
                return True
    return False