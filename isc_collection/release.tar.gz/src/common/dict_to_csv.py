import csv, os
from src import YELLOW, RED, RESET
import src.common


def dict_to_csv(
    data_dict: dict,
    separator: str,
    filename: str = os.environ['ib_output_file']
) -> None:
    ###
    
    try:
        src.common.write_log(f"Writing data to '{filename}'.", verbose=True)
        
        #region Create folder
        if not os.path.exists(os.environ['ib_output_directory']):
            os.makedirs(os.environ['ib_output_directory'])
        #endregion /Create folder
            
            
        with open(filename, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile, delimiter=separator)
            for key in data_dict.keys():
                writer.writerow([key, data_dict[key]])
        src.common.write_log(f"Data successfully written to '{filename}'.", verbose=True)
        
    except IOError:
        src.common.write_log(f"{RED}I/O error occurred while writing to the file '{filename}'.{RESET}", severity="Error", verbose=True)
    except Exception as e:
        src.common.write_log(f"{RED}An unexpected error occurred while writing to '{filename}': {str(e)}.{RESET}", severity="Error", verbose=True)