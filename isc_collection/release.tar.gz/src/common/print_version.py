def print_version(
    entry_point: str
) -> None:
    ###
    
    version_file = open("version.txt", "r")
    print(f"ICS Collection Script, {entry_point}, {version_file.read()}")