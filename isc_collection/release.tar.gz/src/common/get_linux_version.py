import platform


def get_linux_version() -> str:
    ###
    return platform.platform()
