from src import YELLOW, RED, RESET
import src.common


def dedup_file(
    filename: str
) -> None:
    try:
        src.common.write_log(f"Removing possible duplicate records from the '{filename}' file.", verbose=True)
        
        # Open the file in read mode and read lines
        with open(filename, 'r') as file:
            lines = file.readlines()

        # Remove duplicates and keep order
        new_lines = []
        for line in lines:
            if line not in new_lines:
                new_lines.append(line)
            else:
                src.common.write_log(f"Removing duplicate record '{line}'.", verbose=True)

        # Open the file in write mode and write the new lines
        with open(filename, 'w') as file:
            file.writelines(new_lines)

    except FileNotFoundError:
        src.common.write_log(f"{RED}The file '{filename}' does not exist.{RESET}", severity="Error", verbose=True)
    except IOError:
        src.common.write_log(f"{RED}An error occurred trying to read the '{filename}' file.{RESET}", severity="Error", verbose=True)
    except Exception as e:
        src.common.write_log(f"{RED}An error occurred: {str(e)}.{RESET}", severity="Error", verbose=True)