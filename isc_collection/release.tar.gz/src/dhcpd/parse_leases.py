import sys, os
sys.path.append("./tools/python-isc-dhcp-leases")
import isc_dhcp_leases
from src import YELLOW, RED, RESET, DictToObj
import src.ssh, src.common


def parse_leases(
    lease_file_path: str
) -> list:
    ###
    
    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            leases_contents = src.ssh.invoke_command(os.environ['ib_server'], f"cat {lease_file_path}")
    else:
        try:
            with open(lease_file_path, "r", encoding="utf8") as f:
                leases_contents = f.read()
        except FileNotFoundError:
            src.common.write_log(f"{RED}The file '{lease_file_path}' does not exist.{RESET}", severity="Error", verbose=True)
        except IOError:
            src.common.write_log(f"{RED}An IO error occurred trying to read the '{lease_file_path}' file.{RESET}", severity="Error", verbose=True)
        except Exception as e:
            src.common.write_log(f"{RED}An error occurred: {str(e)}.{RESET}", severity="Error", verbose=True)
        
    
    dhcpd_leases = isc_dhcp_leases.IscDhcpLeases(leases_contents, is_data=True).get()
    
    return dhcpd_leases