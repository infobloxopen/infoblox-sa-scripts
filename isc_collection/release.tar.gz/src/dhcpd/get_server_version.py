import os, subprocess
import src.ssh, src.common


def get_server_version(
    server: str
) -> str:
    ###
    
    src.common.write_log("Getting DHCP server version.", verbose=True)
    
    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            result = src.ssh.invoke_command(server, "dhcpd --version")
    else:
        result = subprocess.run(['dhcpd', '--version'], stderr=subprocess.PIPE)
        result = result.stderr.decode('utf-8').strip('\n')
    
    
    return result