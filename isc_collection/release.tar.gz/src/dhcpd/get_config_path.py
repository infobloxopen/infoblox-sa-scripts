import os
import src.ssh, src.common
from src import YELLOW, RED, RESET


def get_config_path(
    server: str
):
    ###
    
    src.common.write_log("Detecting 'dhcpd.config' file location on the server.", verbose=True)
    
    possible_paths = [
        "/etc/dhcp/dhcpd.conf",
        "/etc/dhcp3/dhcpd.conf",
        "/usr/local/etc/dhcpd.conf",
        "/usr/local/etc/dhcp/dhcpd.conf"
    ]
    

    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            for path in possible_paths:
                command = f"test -f {path} && echo exists || echo not_exists"
                result = src.ssh.invoke_command(server, command)
                if result.strip() == "exists":
                    return path
                # else:
                #     src.common.write_log(f"{YELLOW}Could not read file '{path}' on remote server '{os.environ['ib_server']}'.{RESET}", severity="Warning", verbose=True)
    else:
        for path in possible_paths:
            if os.path.exists(path):
                return path
            # else:
            #     src.common.write_log(f"{YELLOW}Could not read file '{path}'.{RESET}", severity="Warning", verbose=True)

    
    src.common.write_log(f"{RED}Could not find 'dhcpd.config' file.{RESET}", severity="Error", verbose=True)
    return ""