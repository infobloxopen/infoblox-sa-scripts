import os, re
from src import YELLOW, RED, RESET, DictToObj
import src.ssh, src.common


#region Parser class
class DhcpdConfParser:
    def __init__(self):
        self.config = {}
        self.current_section = [self.config]
        self.root_path = ""


    def resolve_includes(self, conf_string, root_path=""):
        self.root_path = root_path
        lines = conf_string.split("\n")
        resolved_lines = []
        for line in lines:
            line = line.strip()
            if line.startswith("include"):
                resolved_lines.append(self.parse_include(line))
            else:
                resolved_lines.append(line)
        return "\n".join(resolved_lines)
    
    
    def parse_include(self, line):
        file_path = re.findall(r'"(.*?)"', line)[0]
        file_path = self.root_path + file_path
        
        if os.environ.get('ib_ssh_mode') is not None:
            if os.environ['ib_ssh_mode'] == "True":
                file_content = src.ssh.invoke_command(os.environ['ib_server'], f"cat {file_path}")
                return self.resolve_includes(file_content, self.root_path)
        else:
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File {file_path} not found")
            with open(file_path, "r") as file:
                return self.resolve_includes(file.read(), self.root_path)


    def parse(self, conf_string):
        lines = conf_string.split("\n")
        in_multiline_comment = False
        for line in lines:
            line = line.strip()
            if "/*" in line:
                in_multiline_comment = True
            if "*/" in line:
                in_multiline_comment = False
                continue
            if in_multiline_comment or not line or line.startswith("#"):
                continue
            elif "{" in line:
                self.start_section(line)
            elif "}" in line:
                self.end_section(line)
            else:
                self.add_option(line)


    def start_section(self, line):
        section_name = line.split("{")[0].strip()
        self.current_section[-1][section_name] = {}
        self.current_section.append(self.current_section[-1][section_name])


    def end_section(self, line):
        if len(self.current_section) > 1:
            self.current_section.pop()


    def add_option(self, line):
        if ";" in line:
            option_parts = line.split(";", 1)[0].split(" ", 1)
            if len(option_parts) == 2:
                option_name, option_value = option_parts
                if option_name in self.current_section[-1]:
                    if not isinstance(self.current_section[-1][option_name], list):
                        self.current_section[-1][option_name] = [self.current_section[-1][option_name]]
                    self.current_section[-1][option_name].append(option_value)
                else:
                    self.current_section[-1][option_name] = option_value
            else:
                self.current_section[-1][option_parts[0]] = ""
        else:
            option_name = line.strip()
            self.current_section[-1][option_name] = {}
#endregion /Parser class


#region Parse function
def parse_config(
    root_path: str,
    config_path: str
):
    ###
    
    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            config_string = src.ssh.invoke_command(os.environ['ib_server'], f"cat {root_path}/{config_path}")
    else:
        try:
            with open(config_path) as f:
                config_string = f.read()
        except Exception as e:
            src.common.write_log(f"{RED}Error reading file '{config_path}': {e}.{RESET}", severity="Error", verbose=True)
            return None
            
            
    parser = DhcpdConfParser()
    resolved_config_string = parser.resolve_includes(config_string, root_path)
    parser.parse(resolved_config_string)
    
    
    return parser.config
#endregion /Parse function