import os
import src.ssh, src.common
from src import YELLOW, RED, RESET


def get_leases_path(
    server: str
):
    ###
    
    src.common.write_log("Detecting 'dhcpd.leases' file location on the server.")
    
    possible_paths = [
        "/var/lib/dhcp/dhcpd.leases",
        "/var/lib/dhcpd/dhcpd.leases",
        "/var/db/dhcpd/dhcpd.leases",
        "/var/state/dhcp/dhcpd.leases",
        "/var/lib/dhcp3/dhcpd.leases",
        "/etc/dhcp/dhcpd.leases"
    ]
    

    if os.environ.get('ib_ssh_mode') is not None:
        if os.environ['ib_ssh_mode'] == "True":
            for path in possible_paths:
                command = f"test -f {path} && echo exists || echo not_exists"
                result = src.ssh.invoke_command(server, command)
                if result.strip() == "exists":
                    return path
                # else:
                #     src.common.write_log(f"{YELLOW}Could not read file '{path}' on remote server '{os.environ['ib_server']}'.{RESET}", severity="Warning", verbose=True)
    else:
        for path in possible_paths:
            if os.path.exists(path):
                return path
            # else:
            #     src.common.write_log(f"{YELLOW}Could not read file '{path}'.{RESET}", severity="Warning", verbose=True)

    
    src.common.write_log(f"{RED}Could not find 'dhcpd.leases' file.{RESET}", severity="Error", verbose=True)
    return ""