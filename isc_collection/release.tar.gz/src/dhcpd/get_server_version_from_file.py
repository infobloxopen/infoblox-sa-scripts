import src.common
from src import YELLOW, RED, RESET, DictToObj


def get_server_version_from_file() -> str:
    ###
    
    src.common.write_log(f"{YELLOW}Unable to locate ISC DHCPD server version only by reading filesystem.{RESET}", severity="Warning", verbose=True)
    return "Unknown"