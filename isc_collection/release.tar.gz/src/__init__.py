# ANSI color escape codes
RED         = "\033[91m"
YELLOW      = "\033[33m"
RESET       = "\033[0m"



class DictToObj:
    def __init__(self, in_dict:dict):
        assert isinstance(in_dict, dict)
        for key, val in in_dict.items():
            if isinstance(val, (list, tuple)):
               setattr(self, key, [DictToObj(x) if isinstance(x, dict) else x for x in val])
            else:
               setattr(self, key, DictToObj(val) if isinstance(val, dict) else val)


print('Imported root package')