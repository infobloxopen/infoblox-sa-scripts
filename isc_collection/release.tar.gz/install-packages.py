import os, importlib


def is_package_installed(
    package: str
) -> None:
    ###
    
    try:
        importlib.import_module(package)
        return True
    except ImportError:
        return False


def install_package(
    package_name: str,
    package_path: str
) -> None:
    ###
    
    if not is_package_installed(package_name):
        os.system("pip install " + package_path)



install_package("pyparsing", "./requirements/pyparsing-3.1.2.tar.gz")
install_package("dns", "./requirements/dnspython-2.6.1.tar.gz")
install_package("tabulate", "./requirements/tabulate-0.9.0.tar.gz")
install_package("chardet", "./requirements/chardet-5.2.0.tar.gz")