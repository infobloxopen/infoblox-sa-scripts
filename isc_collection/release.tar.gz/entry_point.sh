#!/bin/bash


source ./.venv/bin/activate


#region Functions
write_log() {
    local text="$1"
    local severity="${2:-Info}"
    local verbose="${3:-true}"

    # Create folder
    if [ ! -d "$log_directory" ]; then
        mkdir -p "$log_directory"
    fi

    # Format spaces
    local severity_length=${#severity}
    local severity_stamp="[$severity]"
    if [ $severity_length -le 7 ]; then
        for ((write_log_i=$severity_length; write_log_i<10; write_log_i++)); do
            severity_stamp+=" "
        done
    fi

    # Write to log
    local timestamp=$(date +"%Y-%m-%d %H-%M-%S->")$(date +"%3N")
    echo "$timestamp $severity_stamp $text" >> "$log_file"

    # Output the same
    if [ "$verbose" = true ]; then
        echo "$text"
    fi
}
#endregion /Functions


#region Settings veriables
output_directory="./@output"
log_directory="./@logs"
date_time=$(date +"%Y-%m-%d_%H-%M-%S")
output_file="$output_directory/$date_time.csv"
log_file="$log_directory/$date_time.log"
echo "Log file: $log_file"
echo "Output file: $output_file"
#endregion /Settings veriables


#region Initial output to log
write_log "Log file initialized."
#endregion /Initial output to log


#region Install Python packages
write_log "Installing Python packages."
python install-packages.py

if [ $? -eq 0 ]
then
    write_log "Done."
else
    write_log "Some modules were missing and failed to install."
fi
#endregion /Install Python packages


# Named Parameter
query=${1?"Usage: $0 'mode=dhcp:packer;path=./_dhcp_data/|mode=dns:ssh;server=10.10.6.30,10.10.6.31'"}


# Convert the parameter into an array
IFS='|' read -r -a array <<< "$query"

# Array to store the parsed parameters that match the conditions
parsed_params=()

# Loop through the array and parse each parameter
for index in "${!array[@]}"
do
    parsed_param=${array[index]}

    # Extract mode and value
    IFS=';' read -r -a split_param <<< "$parsed_param"
    mode="${split_param[0]}"
    value="${split_param[1]}"

    case "$mode" in
        "mode=dhcp:packer"|"mode=dns:packer")
            if [[ $value == path=* ]]; then
                path="${value#*=}"
                parsed_params+=("$mode, $path")
            else
                write_log "Parameter '$index': '$parsed_param' does not match the pattern."
            fi
            ;;
        "mode=dhcp:local"|"mode=dns:local")
            if [[ $value == path=* || -z $value ]]; then
                path="${value#*=}"
                parsed_params+=("$mode, $path")
            else
                write_log "Parameter '$index': '$parsed_param' does not match the pattern."
            fi
            ;;
        "mode=dhcp:ssh"|"mode=dns:ssh")
            if [[ $value == server=* ]]; then
                server="${value#*=}"
                parsed_params+=("$mode, $server")
            else
                write_log "Parameter '$index': '$parsed_param' does not match the pattern."
            fi
            ;;
        "mode=dhcp:mount"|"mode=dns:mount")
            if [[ $value == path=* ]]; then
                path="${value#*=}"
                parsed_params+=("$mode, $path")
            else
                write_log "Parameter '$index': '$parsed_param' does not match the pattern."
            fi
            ;;
        *)
            write_log "Parameter '$index': '$parsed_param' does not match any condition."
            ;;
    esac
done


#region Print parsed parameters
for i in "${!parsed_params[@]}"
do
    write_log "Parsed parameter $i: ${parsed_params[i]}"
done
#endregion /Print parsed parameters


# Another loop to handle the new conditions
for i in "${!parsed_params[@]}"
do
    write_log "=============================="
    # Extract mode and value
    mode="${parsed_params[i]%%, *}"
    value="${parsed_params[i]#*, }"

    # Output current parameter separating mode and path
    write_log "Mode: $mode; parameter: $value"

    #region Conditions
    if [[ $mode == "mode=dhcp:packer" ]]; then
        command="python ./scripts/dhcp-main-local-packer.py --path \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dhcp:ssh" ]]; then
        command="python ./scripts/dhcp-main-local-ssh.py --server \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dhcp:local" ]]; then
        command="python ./scripts/dhcp-main-local.py --dhcpd-config-path \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dhcp:mount" ]]; then
        command="python ./scripts/dhcp-main-local-mount.py --path \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dns:packer" ]]; then
        command="python ./scripts/dns-main-local-packer.py --path \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dns:ssh" ]]; then
        command="python ./scripts/dns-main-local-ssh.py --server \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dns:local" ]]; then
        command="python ./scripts/dns-main-local.py --named-config-path \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi

    if [[ $mode == "mode=dns:mount" ]]; then
        command="python ./scripts/dns-main-local-mount.py --path \"$value\" --log-file \"$log_file\" --output-file \"$output_file\""
    fi
    #endregion /Conditions

    write_log "Executing '$command'."
    eval $command

    write_log "=============================="
done