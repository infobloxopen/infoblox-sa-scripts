# Introduction

# Collection Script logic
Here follows the more or less detailed description of the script logic.

## DNS

First stage is the most important as it will collect all zone files on the local machine, so that we can further analyze them and perform calculations.

1. Download DNS zone files to local `./data` folder.
   1. Get the list of DNS servers from the YAML file.
   2. Create folder structure for each DNS server in `./data` folder.
   3. Get SSH credentials for each DNS server.
   4. Per each server:
      1. Download BIND9 configuration using `named-checkconf -p` as local file.
      2. Read configuration and generate list of DNS zones with location of files.
      3. Download all DNS zone files.
   


# Pre-requisites
## BIND9 Permissions
1. Script will download BIND9 configuration and zone files on the local machine. To ensure that, you must grant read permissions to all configuration files, zone files, and corresponding directories (the script will use `named-checkconf -p` command to download BIND9 configuration, and the command will `chdir` to the directories used in config files).


sshfs 10.10.6.30:/ /home/udadzimau/mnt/10.10.6.30/
sshfs 10.10.6.31:/ /home/udadzimau/mnt/10.10.6.31/

fusermount3 -u /home/udadzimau/mnt/10.10.6.30/